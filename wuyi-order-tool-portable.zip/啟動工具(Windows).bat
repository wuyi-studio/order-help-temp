@echo off
chcp 65001 >nul
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel%==0 (
  echo 🚀 正在啟動本機伺服器：http://localhost:8765
  echo ⚠️ 使用期間請勿關閉此視窗，關閉視窗即停止伺服器。
  start "" "http://localhost:8765"
  python -m http.server 8765
) else (
  echo 找不到 Python，改為直接以瀏覽器開啟 index.html...
  start "" "index.html"
)
