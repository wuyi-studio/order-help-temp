#!/bin/bash
cd "$(dirname "$0")"
PORT=8765
while lsof -i :$PORT >/dev/null 2>&1; do
  PORT=$((PORT + 1))
done
echo "🚀 正在啟動本機伺服器：http://localhost:$PORT"
echo "⚠️ 使用期間請勿關閉此視窗，關閉視窗即停止伺服器。"
(sleep 1 && open "http://localhost:$PORT") &
python3 -m http.server $PORT
